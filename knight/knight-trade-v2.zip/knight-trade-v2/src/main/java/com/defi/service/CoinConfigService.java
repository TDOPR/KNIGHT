package com.defi.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.defi.entity.CoinConfigEntity;

/**
 * eth token充值信息采集JOB表
 *
 * @date 2019-12-06 02:01:15
 */
public interface CoinConfigService extends IService<CoinConfigEntity> {


}

