package com.defi.utils;

/**
 *
 */
public class CommonRedisKey {

    // 提币key
    public static final String WITHDRAW_CHECK_KEY = "WITHDRAW_CHECK_KEY";

    // 充币key
    public static final String RECHARGE_CHECK_KEY = "RECHARGE_CHECK_KEY";
}
