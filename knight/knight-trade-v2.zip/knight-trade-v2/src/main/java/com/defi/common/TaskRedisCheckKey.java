package com.defi.common;

/**
 * @author Jetty Li
 * @email 1262385646@qq.com
 * @date 2020/5/15 0015
 */
public class TaskRedisCheckKey {

    public static final String ANALYZE_EVENT = "ANALYZE_EVENT";

    public static final String STATIC_INCOME = "STATIC_INCOME";

}
