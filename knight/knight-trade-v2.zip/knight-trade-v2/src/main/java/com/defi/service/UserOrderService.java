package com.defi.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.defi.entity.UserOrderEntity;

/**
 * 用户表
 *
 * @date 2021-12-24 11:09:24
 */
public interface UserOrderService extends IService<UserOrderEntity> {

}

