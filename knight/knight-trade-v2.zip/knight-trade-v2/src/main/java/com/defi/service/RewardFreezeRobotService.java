package com.defi.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.defi.entity.RewardFreezeRobotEntity;

import java.util.Map;

/**
 *
 */
public interface RewardFreezeRobotService extends IService<RewardFreezeRobotEntity> {

    Map getRewardFreezeRobotAmount(int uid,int robotLevel,String deadTime);

}

